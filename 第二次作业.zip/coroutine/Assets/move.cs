﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    Coroutine myCoroutine;
    void Start()
    {
        myCoroutine = StartCoroutine(MoveObject());
    }
    private void Update()
    {
        if (Input.GetKey(KeyCode.S))
        {
            StopCoroutine(myCoroutine);
        }
    }
    IEnumerator MoveObject()
    {
        while (true)
        {

            transform.position += transform.forward * Time.deltaTime * 5;
            yield return null;
        }
    }


}
    




